import axios from 'axios';
const baseURL = '/api'; //定义基础URL
const instance = axios.create({baseURL: baseURL}); //使用基础URL
import {useTokenStore}from './token'; //导入token状态
import router from './router';

instance.interceptors.request.use( //定义请求拦截器 
	(config) => {
	 const tokenStore = useTokenStore(); //获取Pinia中的token
	 if(tokenStore.token){//将token添加到请求头中 
		 config.headers.Authorization = tokenStore.token;
	 }
	 return config
 },
 (error) => { 
	 Promise.reject(error)
	 }
)

instance.interceptors.response.use( //定义响应拦截器
  response => {
    if(response.data.code == 0) return Promise.reject(response.data.msg);
	if (response.data.code == 4) {
		router.push("/login");
		return Promise.reject('请先登录');
	  }
    return response;
  },
  error => {
    return Promise.reject(error);
  }
);
export default instance; //导出axios对象