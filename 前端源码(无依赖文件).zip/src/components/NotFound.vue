<template>
  <el-container>
    <el-header>
      <h1>亲亲,您访问的路径不存在哦</h1>
    </el-header>
    <el-main>
      <p>少年一贯快马扬帆，道阻且长不转弯。</p>
        <p>要盛大、要绚烂、要哗然，要为了未来的光，就肯翻越万水千山！</p>
      <el-button type="primary" @click="goHome">返回首页</el-button>
    </el-main>
  </el-container>
</template>

<script>
import { ElContainer, ElHeader, ElMain, ElButton } from 'element-plus';

export default {
  name: 'NotFound',
  components: {
    ElContainer,
    ElHeader,
    ElMain,
    ElButton
  },
  methods: {
    goHome() {
      this.$router.push('/');
    }
  }
}
</script>

<style scoped>
.el-header, .el-main {
  padding: 20px;
  text-align: center;
}

.el-button {
  margin-top: 20px;
}
</style>