<template>
  <el-card class="login-card">
    <div class="login-header">
      <h3 class="login-title">欢迎登录</h3>
    </div>
    <el-form
      ref="loginForm"
      :model="loginForm"
      :rules="rules"
      class="login-form"
    >
      <el-form-item label="账户" prop="username">
        <el-input
          v-model="loginForm.username"
          prefix-icon="el-icon-user"
        ></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input
          type="password"
          v-model="loginForm.password"
          prefix-icon="el-icon-lock"
        ></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" class="login-button" @click="submitForm"
          >登录</el-button
        >
      </el-form-item>
    </el-form>
    <el-button @click="reg"
          >还没有账户? 去注册！</el-button
        >
  </el-card>
  
</template>

<script>
import axios from "../axios";
import { ElMessage } from "element-plus";
import { useTokenStore } from "../token"; //导入token状态

export default {
  data() {
    return {
      loginForm: {
        username: "",
        password: "",
      },
      rules: {
        username: [
          { required: true, message: "请输入账户", trigger: "blur" },
          {
            min: 3,
            max: 15,
            message: "长度在 3 到 15 个字符",
            trigger: "blur",
          },
          {
            pattern: /^[A-Za-z0-9]+$/,
            message: "账户只能包含字母和数字",
            trigger: "blur",
          },
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, message: "密码长度不能少于6位", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    submitForm() {
      this.$refs.loginForm.validate((valid) => {
        if (valid) {
          this.login();
        } else {
          ElMessage.error("表单验证失败");
          return false;
        }
      });
    },
    reg(){
      this.$router.push("/reg");
    },
    login() {
      axios
        .post("/login", this.loginForm)
        .then((response) => {
          ElMessage.success("登录成功");
          const tokenStore = useTokenStore();
          tokenStore.setToken(response.data.data);
        console.log(this.loginForm);
          this.$router.push("/");
        })
        .catch((error) => {
          ElMessage.error(error);
        });
    },
  },
};
</script>

<style scoped>
.login-card {
  width: 360px;
  margin: 100px auto;
  padding: 30px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.login-header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
}

.login-title {
  font-size: 24px;
  color: #333;
}

.login-form {
  width: 100%;
}

.login-button {
  width: 100%;
  font-size: 16px;
  letter-spacing: 2px;
}

/* 添加一些动画效果 */
.login-card {
  transition: transform 0.3s ease-in-out;
}

.login-card:hover {
  transform: translateY(-5px);
}

/* 表单输入框图标样式 */
.el-input__icon {
  color: #666;
}

/* 表单输入框样式 */
.el-input__inner {
  border-radius: 4px;
}

/* 表单输入框聚焦时的样式 */
.el-input__inner:focus {
  border-color: #409eff;
}
</style>