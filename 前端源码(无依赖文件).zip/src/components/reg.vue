<template>
  <el-card class="reg-card">
    <div class="reg-header">
      <h3 class="reg-title">欢迎注册</h3>
    </div>
    <el-form ref="regForm" :model="regForm" :rules="rules" class="reg-form">
      <el-form-item label="用户名" prop="name">
        <el-input v-model="regForm.name" prefix-icon="el-icon-user"></el-input>
      </el-form-item>
      <el-form-item label="账户" prop="username">
        <el-input v-model="regForm.username" prefix-icon="el-icon-user"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input type="password" v-model="regForm.password" prefix-icon="el-icon-lock"></el-input>
      </el-form-item>
      <el-form-item label="手机号" prop="tel">
        <el-input v-model="regForm.tel" prefix-icon="el-icon-mobile-phone"></el-input>
      </el-form-item>
      <el-form-item>
      <el-form-item label="年龄" prop="age">
  <el-input-number v-model="regForm.age" placeholder="请输入年龄" :min="0" :max="100"></el-input-number>&nbsp;&nbsp;&nbsp;
</el-form-item>
      <el-form-item prop="sex">
        <el-radio-group v-model="regForm.sex">
          <el-radio :label="1">男</el-radio>
          <el-radio :label="2">女</el-radio>
        </el-radio-group>
      </el-form-item>
    
        <el-button type="primary" class="reg-button" @click="submitForm">注册</el-button>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script>
import axios from '../axios';
import { ElMessage, ElOption, ElSelect, ElRadio, ElRadioGroup } from 'element-plus';

export default {
  components: {
    ElOption,
    ElSelect,
    ElRadio,
    ElRadioGroup
  },
  data() {
    return {
      regForm: {
        username: '',
        password: '',
        name: '',
        age: 0,
        sex: null,
        tel: ''
      },
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' },
          { pattern: /^[A-Za-z0-9]+$/,
          message: '用户名只能包含字母和数字',
          trigger: 'blur' 
        }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码长度不能少于6位', trigger: 'blur' }
        ],
        name: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' },
        ],
        age: [
          { required: true, message: '请选择年龄', trigger: 'change' },
          { pattern: /[^0]/, message: '年龄出错', trigger: 'blur' }
        ],
        sex: [
          { required: true, message: '请选择性别', trigger: 'change' }
        ],
        tel: [
          { required: true, message: '请输入手机号', trigger: 'blur' },
          { pattern: /^1[3-9]\d{9}$/, message: '手机号格式不正确', trigger: 'blur' }
        ]
      }
    };
  },methods: {
    submitForm() {
      this.$refs.regForm.validate((valid) => {
        if (valid) {
          this.reg();
        } else {
          ElMessage.error('表单验证失败');
          return false;
        }
      });
    },
    reg() {
      axios.post('/reg', this.regForm)
        .then(response => {
          ElMessage.success('注册成功');
          this.$router.push('/login');
        })
        .catch(error => {
          ElMessage.error(error);
        });
    }
  }
};
</script>

<style scoped>
.reg-card {
  width: 360px;
  margin: 100px auto;
  padding: 30px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.reg-header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 20px;
}

.reg-title {
  font-size: 24px;
  color: #333;
}

.reg-form {
  width: 100%;
}

.reg-button {
  width: 100%;
  font-size: 16px;
  letter-spacing: 2px;
}

/* 添加一些动画效果 */
.reg-card {
  transition: transform 0.3s ease-in-out;
}

.reg-card:hover {
  transform: translateY(-5px);
}

/* 表单输入框图标样式 */
.el-input__icon {
  color: #666;
}

/* 表单输入框样式 */
.el-input__inner {
  border-radius: 4px;
}

/* 表单输入框聚焦时的样式 */
.el-input__inner:focus {
  border-color: #409eff;
}
</style>