<template>
  <div class="chat-room">
    <el-card class="box-card">
      <template #header>
        <div class="clearfix">
          <span>聊天室</span>
        </div>
      </template>
      <div class="messages-container">
        <div
          v-for="(msg, index) in messages"
          :key="index"
          class="message"
          :class="{ 'my-message': msg.isMine }"
        >
          <div class="message-content">
            <div class="message-info">
              <span class="username">{{ msg.username }}</span>
              &nbsp;
              <span class="time">{{ msg.time }}</span>
            </div>
            <div class="message-text">
              <img v-if="msg.type === 'image'" :src="msg.text" alt="图片消息" />
              <span v-else>{{ msg.text }}</span>
            </div>
          </div>
          <el-avatar :src="msg.avatar"  class="avatar"></el-avatar>
        </div>
      </div>
      <div class="input-container">
        <el-input
          type="textarea"
          v-model="inputMessage"
          placeholder="请输入消息内容或图片URL(图片只能单发)"
          @keyup.enter="sendMessage"
        />
        <el-button type="primary" @click="sendMessage">发送</el-button>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { ElMessage } from 'element-plus';
import axios from "../axios";
import { useTokenStore } from '../token'; //导入token状态

const messages = ref([]);
const inputMessage = ref('');
const currentUser = ref({
  username: '',
  avatar: ' '
});

axios.get("/getname")
  .then((response) => {
    currentUser.value.username = response.data.data.name;
    currentUser.value.avatar = response.data.data.headImg;
  })
  .catch((error) => {
    ElMessage.error("信息获取失败");
  });


const ws = new WebSocket('ws://123.60.133.183:8080/PP');
ws.onopen = function(event) {
  const tokenStore = useTokenStore(); //获取Pinia中的token
  ws.send(tokenStore.token);
};
ws.onclose = function(event) {
  if (event.reason === "身份验证失败") {
    ElMessage.error("身份验证失败,连接已关闭,请刷新界面");
  } else {
    ElMessage.error("连接已关闭");
  }
};
ws.onerror = function(event) {
  ElMessage.error("连接已关闭");
};
ws.onmessage = function(event) {
  try {
    const message = JSON.parse(event.data);
    const isImage = isImageUrl(message.text);
    message.type = isImage ? 'image' : 'text';
    const newMessage = {
      ...message,
      isMine: false,
      type: isImage ? 'image' : 'text' 
    };
    messages.value.push(newMessage);
  } catch (error) {
    ElMessage.error("解析消息失败");
  }
};

function sendMessage() {
  if (inputMessage.value.trim()) {
    const message = {
      username: currentUser.value.username,
      avatar: currentUser.value.avatar,
      text: inputMessage.value,
      time: new Date().toLocaleTimeString(),
      isMine: true,
      type: isImageUrl(inputMessage.value) ? 'image' : 'text'
    };
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message.username+'.and'+message.avatar+'.and'+message.text+'.and'+message.time+'.and'+message.type);
    } else {
      ElMessage.error("WebSocket 状态不正确，无法发送消息");
      return;
    }
    messages.value.push(message);
    inputMessage.value = '';
  }
}

function isImageUrl(url) {
  const pattern = /^https?:\/\/.+\.(jpg|jpeg|png|gif)$/i;
  return pattern.test(url);
}

const isMine = computed(() => (msg) => msg.isMine);
</script>

<style scoped>
.chat-room {
  max-width: 600px;
  margin: 20px auto;
}
.box-card {
  display: flex;
  flex-direction: column;
}
.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}
.message {
  display: flex;
  margin-bottom: 20px;
  align-items: flex-start;
}
.message-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  max-width: 70%;
}
.my-message {
  justify-content: flex-end;
}
.my-message .message-content {
  justify-content: flex-end;
}
.avatar {
  margin: 0 10px;
}
.username {
  font-weight: bold;
}
.time {
  font-size: 12px;
  color: #666;
}
.message-text {
  margin-top: 5px;
  background-color: #f5f5f5;
  padding: 10px;
  border-radius: 5px;
  display: flex;
  align-items: center;
}
.message-text img {
  max-width: 100%;
  height: auto;
}
.input-container {
  display: flex;
  align-items: center;
  padding: 10px;
}
.message:not(.my-message) .message-text {
  background-color: #e0f7fa; /* 非我的信息时的背景色为淡蓝色 */
}

.message:not(.my-message) {
  justify-content: flex-start; /* 非我的信息时，消息整体向左对齐 */
}

.message:not(.my-message) .avatar {
  order: -1; /* 将头像移动到消息内容的前面 */
}
</style>