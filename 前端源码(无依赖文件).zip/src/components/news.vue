<template>
  <el-table :data="newsList" style="width: 100%">
    <el-table-column prop="title" label="标题"></el-table-column>
    <el-table-column prop="typeId" label="分类"></el-table-column>
    <el-table-column prop="createTime" label="创建时间" ></el-table-column>
    <el-table-column label="操作" align="center">
      <template #default="{ row }">
        <el-button type="primary" size="small" @click="preview(row)" style="width: 50px;">预览</el-button>
        <el-button type="info" size="small" @click="showComments(row)" style="width: 50px;">评论</el-button>
    <el-button type="primary" size="small" @click="handleEdit(row); currentRow = row" style="width: 50px;">编辑</el-button>
    <el-button type="danger" size="small" @click="handleDelete(row)" style="width: 50px;">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-dialog v-model="dialogVisible" width="60%">
    <div v-html="newsDetail"></div>
    <template #footer>
      <el-button @click="dialogVisible = false">关闭</el-button>
    </template>
  </el-dialog>
 <el-dialog v-model="editDialogVisible" title="编辑新闻" width="60%">
    <el-form :model="currentRow" :rules="rules" ref="editForm">
      <el-form-item label="标题" prop="title">
        <el-input v-model="currentRow.title"></el-input>
      </el-form-item>
      <el-form-item label="分类" prop="typeId">
        <el-select v-model="currentRow.typeId" placeholder="请选择分类">
          <el-option
            v-for="category in typeOptions"
            :key="category"
            :value="category">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="内容" prop="content">
        <el-input type="textarea" v-model="currentRow.content" :rows="15"></el-input>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="editDialogVisible = false">取消</el-button>
      <el-button type="primary" @click="submitEdit">保存</el-button>
    </template>
  </el-dialog>
  <el-dialog v-model="commentsDialogVisible" title="评论列表" width="60%">
    <div v-for="comment in comments" :key="comment.id" class="comment-item">
      <div class="comment-info">
        <span class="comment-id">{{ comment.userId }}说:</span>
        <div class="comment-text">{{ comment.text }}</div>
      </div>
      <span class="comment-time">{{ comment.time }}</span>
      <el-button type="danger" size="small" @click="deleteComment(comment.id)">删除</el-button>
    </div>
    <el-form :model="commentForm" ref="commentFormRef" @submit.prevent="submitComment">
      <el-form-item label="发表评论" prop="content" label-width="100px">
        <el-input type="textarea" v-model="commentForm.content" autosize placeholder="请输入评论内容"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitComment">提交</el-button>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="commentsDialogVisible = false">关闭</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref } from 'vue';
import axios from "../axios";
import { ElMessage } from "element-plus";

// 初始数据
const newsList = ref([]);
const newsDetail = ref('');
const dialogVisible = ref(false);
const editDialogVisible = ref(false);
const currentRow = ref({});
const editForm = ref(null);
const typeOptions = ref([]);
const commentsDialogVisible = ref(false);
const comments = ref([]);
const commentForm = ref({ content: '' });
// 请求分类数据
axios.get("/gettype")
  .then((response) => {
    typeOptions.value = response.data.data;
  })
  .catch((error) => {
    ElMessage.error("分类获取失败");
  });
const rules = ref({
  title: [
    { required: true, message: "标题不能为空", trigger: "blur" },
    { min: 3, max: 50, message: "标题长度必须在3到50个字符之间", trigger: "blur" },
  ],
  content: [
    { required: true, message: "内容不能为空", trigger: "blur" },
    { min: 10, max: 500, message: "内容长度必须在10到500个字符之间", trigger: "blur" },
  ],
  typeId: [{ required: true, message: "请选择分类", trigger: "blur" }],
});
axios
    .get("/getnews")
    .then((response) => {
        newsList.value = response.data.data;
    })
    .catch((error) => {
        ElMessage.error("数据加载失败: " + error);
    });

const preview = (row) => {
  const id = row.id;
  axios
    .get(`/getnewsdata?id=${encodeURIComponent(id)}`)
    .then((response) => {
      const newsContent = response.data.data;
      const imgRegex = /https?:\/\/[^\s"]+/g;
      const imgUrls = newsContent.match(imgRegex);
      let safeContent = newsContent;
      if (imgUrls) {
        imgUrls.forEach(imgUrl => {
          safeContent = safeContent.replace(imgUrl, `<img src="${imgUrl}" style="max-width:100%; height:auto;" />`);
        });
      }
      newsDetail.value = safeContent;
      dialogVisible.value = true;
    })
    .catch((error) => {
      ElMessage.error("数据加载失败: " + error.message);
    });
};

const handleEdit = (row) => {
  const id = row.id;
    axios
        .get(`/getnewsdata?id=${encodeURIComponent(id)}`)
        .then((response) => {
            currentRow.value.content = response.data.data;
            editDialogVisible.value = true
        })
        .catch((error) => {
            ElMessage.error("数据加载失败: " + error.message);
        });
};

const handleDelete = (row) => {
    const id = row.id;
    axios
        .delete(`/delenews/${id}`)
        .then((response) => {
            ElMessage.success("删除成功");
            newsList.value = newsList.value.filter(item => item.id !== id);
        })
        .catch((error) => {
            ElMessage.error("数据加载失败: " + error.message);
        });
};

// 保存编辑
const submitEdit = () => {
  editForm.value.validate((valid) => {
    if (valid) {
      const newsData = {
        id: currentRow.value.id,
        title: currentRow.value.title,
        content: currentRow.value.content,
        typeId: currentRow.value.typeId,
      };
      axios
        .put("/upnews", newsData)
        .then((response) => {
          ElMessage.success("修改成功");
          editDialogVisible.value = false
        })
        .catch((error) => {
          ElMessage.error("保存失败: " + error.message);
        });
    } else {
      ElMessage.error("表单验证失败");
    }
  });
};
const showComments = (row) => {
  axios.get(`/getcomments?id=${encodeURIComponent(row.id)}`)
    .then(response => {
      comments.value = response.data.data;
      commentsDialogVisible.value = true;
      commentForm.value.id=row.id;
    })
    .catch(error => {
      ElMessage.error("评论加载失败: " + error);
    });
};

const submitComment = () => {
  if (!commentForm.value.content) {
    ElMessage.error("评论内容不能为空");
    return;
  }
  axios.post('/addcomment', { newsId: commentForm.value.id, text: commentForm.value.content })
    .then(() => {
      ElMessage.success("评论成功");
      commentForm.value.content = '';
      axios.get(`/getcomments?id=${encodeURIComponent(commentForm.value.id)}`)
        .then(response => {
          comments.value = response.data.data;
          commentsDialogVisible.value = true;
        })
        .catch(error => {
          ElMessage.error("评论加载失败: " + error.message);
        });
    })
    .catch(error => {
      ElMessage.error("评论失败: " + error.message);
      commentForm.value.content = '';
    });
};
const deleteComment = (commentId) => {
  axios.delete(`/delcomment/${commentId}`)
    .then(() => {
      ElMessage.success("评论删除成功");
      axios.get(`/getcomments?id=${encodeURIComponent(commentForm.value.id)}`)
        .then(response => {
          comments.value = response.data.data;
        })
        .catch(error => {
          ElMessage.error("评论加载失败: " + error.message);
        });
    })
    .catch(error => {
      ElMessage.error("评论删除失败: " + error);
    });
};
</script>