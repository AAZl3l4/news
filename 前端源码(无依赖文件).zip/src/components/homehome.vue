<template>
  <el-carousel :interval="4000" type="card" height="300px" class="carousel-container">
    <el-carousel-item v-for="item in imageUrl" :key="item">
      <img :src="item.url" alt="轮播图" class="carousel-image"/>
    </el-carousel-item>
  </el-carousel>
  <div class="details-container">
      <el-card>
            <details>
                <summary>关于我</summary>
                <p>&nbsp;&nbsp;&nbsp;我是帅哥</p>
            </details>
        <details-summary>
          <template #title>用户反馈</template>
          <p>支持反馈,不一定改正</p>
        </details-summary>
      </el-card>

    <el-card class="marquee-container">
      <marquee direction="left" loop="0" scrolldelay="100" scrollAmount="3" behavior="scroll">
        <h3>广告候补位&nbsp;🐕:)&nbsp;~~~~</h3>
      </marquee>
    </el-card>
  </div>
</template>

<script setup>
const imageUrl = [
  { url: "src/assets/1.gif"  },
  { url: "src/assets/2.jpg"  },
  { url: "src/assets/3.jpg"  },
  { url: "src/assets/4.jpg"  },
  { url: "src/assets/5.jpg"  }
  ];
</script>

<style scoped>
h3{
  color: red;
}
.details-container {
  margin-top: 120px; /* 根据需要调整这个值来设置间距 */
}
.container {
  position: fixed; /* 固定位置，不随滚动条滚动 */
  left: 55%; /* 容器左边距离视窗左边50% */
  bottom: 10%; /* 容器底部紧贴视窗底部 */
  transform: translateX(-50%); /* 向左移动50%自身宽度，实现水平居中 */
  text-align: center; /* 使内部文本水平居中 */
}

h1 {
  font-size: 48px; /* 设置标题的字体大小 */
  margin: 0; /* 移除标题的默认外边距 */
}
.carousel-container .el-carousel__item {
  display: flex;
  justify-content: center;
  align-items: center;
}

.carousel-image {
  width: 100%;
  max-height: 100%;
  object-fit: contain; /* 也可以使用 'cover' 来填充整个容器，但可能会裁剪图片 */
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}
</style>
