<template>
  <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
    <el-form-item label="标题" prop="title">
      <el-input v-model="form.title" placeholder="请输入标题"></el-input>
    </el-form-item>
    <el-form-item label="分类" prop="typeId">
      <el-select v-model="form.typeId" placeholder="请选择分类">
        <el-option
          v-for="category in typeOptions"
          :key="category"
          :value="category"
        >
        </el-option>
      </el-select>
    </el-form-item>
    <el-form-item label="内容" prop="content">
      <el-input
        type="textarea"
        v-model="form.content"
        placeholder="请输入内容 支持HTML标签 图片可直接输入url"
        :rows="21"
      ></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script setup>
import { ref } from "vue";
import { ElMessage } from "element-plus";
import axios from "../axios";
import { useTokenStore } from "../token"; //导入token状态
import { useRouter } from "vue-router";
import router from "../router";
const categories = ref([]);
const typeOptions = ref([]);
axios
  .get("/gettype")
  .then((response) => {
    typeOptions.value = response.data.data;
  })
  .catch((error) => {
    // 失败
    ElMessage.error("分类获取失败");
  });

const formRef = ref(null);
const form = ref({
  title: "",
  content: "",
  typeId: "",
});
const rules = {
  title: [
    { required: true, message: "标题不能为空", trigger: "blur" },
    {
      min: 3,
      max: 50,
      message: "标题长度必须在3到50个字符之间",
      trigger: "blur",
    },
  ],
  content: [
    { required: true, message: "内容不能为空", trigger: "blur" },
    {
      min: 10,
      max: 500,
      message: "内容长度必须在10到500个字符之间",
      trigger: "blur",
    },
    {
      validator: (rule, value, callback) => {
        if (value && value.includes("<script>")) {
          callback(new Error("为防止xss攻击,禁止使用js标签"));
        } else {
          callback();
        }
      },
      trigger: "blur",
    },
  ],
  typeId: [{ required: true, message: "请选择分类", trigger: "blur" }],
};

const submitForm = () => {
  formRef.value.validate((valid) => {
    if (valid) {
      axios
        .post("/addnews", form.value)
        .then((response) => {
          ElMessage.success("提交成功");
          form.value={}
        })
        .catch((error) => {
          // 失败
          console.log(form.value);
          ElMessage.error(error);
        });
    } else {
      ElMessage.error("表单验证失败");
      return false;
    }
  });
};
</script>

<style scoped>
.el-form {
  margin: 0 auto;
}
.el-form-item {
  margin-bottom: 25px;
}
/* 圆角按钮样式 */
.el-button--primary {
  border-radius: 20px; /* 调整圆角大小 */
  transition: all 0.3s ease; /* 添加过渡效果 */
}

/* 按钮交互动画 */
.el-button--primary:hover {
  background-color: #5a95f5; /* 鼠标悬停时的背景色 */
  border-color: #5a95f5; /* 鼠标悬停时的边框色 */
}
</style>