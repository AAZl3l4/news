<template>
  <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
    <el-form-item label="分类名称" prop="typeName">
      <el-input v-model="form.typeName" placeholder="请输入分类名称"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm">添加分类</el-button>
    </el-form-item>
  </el-form>
  <el-card>
    <template #header>
      <div class="clearfix">
        <span>现有分类列表</span>
      </div>
    </template>
    <el-table :data="categories">
      <el-table-column prop="name" label="分类名称" width="180"></el-table-column>
      <el-table-column label="操作" align="right">
        <template v-slot="scope">
          <el-button size="mini" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { ElMessage, ElForm, ElInput, ElButton } from 'element-plus';
import axios from "../axios";

const categories = ref([]);
const formRef = ref(null);
const form = reactive({
  typeName: ''
});

const rules = {
  typeName: [
    { required: true, message: '分类名称不能为空', trigger: 'blur' },
    { min: 2, message: '分类名称至少需要2个字符', trigger: 'blur' }
  ]
};

const handleDelete = (category) => {
const index = categories.value.findIndex(item => item.name === category.name);
  if (index !== -1) {
  axios.delete("/delenewstype", {
  params: {
    categoryName: category.name
  }
}).then((response) => {
  ElMessage.success("删除成功");
  categories.value.splice(index, 1);
}).catch((error) => {
  ElMessage.error("数据加载失败: " + error.message);
});
  }
};

const submitForm = () => {
  formRef.value.validate((valid) => {
    if (valid) {
      axios.post('/addtype', form)
        .then(response => {
          // 添加新分类到数组
          categories.value.push({ name: form.typeName }); 
          ElMessage.success('分类添加成功');
          form.name = '';
        })
        .catch(error => {
          ElMessage.error('添加失败');
        });
    } else {
      ElMessage.error('表单验证失败');
      return false;
    }
  });
};

onMounted(() => {
  axios.get('/gettype')
    .then(response => {
      categories.value = response.data.data.map(item => ({ name: item }));;

    })
    .catch(error => {
      ElMessage.error('分类列表加载失败');
    });
});
</script>

