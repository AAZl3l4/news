<template>
  <el-form ref="formRef" :model="form" :rules="rules" label-width="50px">
    <el-form-item label="分类:" prop="typeId">
      <el-select v-model="form.typeId" placeholder="请选择分类" style="width: 250px;">
        <el-option v-for="category in typeOptions" :key="category" :value="category"></el-option>
      </el-select>
      &nbsp;&nbsp;&nbsp;
      <el-button type="success" round @click="looktype">按照分类筛选</el-button>
    </el-form-item>
  </el-form>
  <el-table :data="newsList" style="width: 100%">
    <el-table-column prop="title" label="标题"></el-table-column>
    <el-table-column prop="typeId" label="分类"></el-table-column>
    <el-table-column prop="createTime" label="创建时间"></el-table-column>
    <el-table-column label="操作" align="center">
      <template #default="{ row }">
        <span class="like-button" @click="toggleLike(row)" :class="{ 'liked': row.liked }">&#x2764;</span>
        &nbsp;&nbsp;
        <el-button type="primary" size="small" @click="preview(row)">预览内容</el-button>
        &nbsp;
        <el-button type="info" size="small" @click="showComments(row)">评论</el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-dialog v-model="dialogVisible" width="60%">
    <div v-html="newsDetail"></div>
    <template #footer>
      <el-button @click="dialogVisible = false">关闭</el-button>
    </template>
  </el-dialog>
  <el-dialog v-model="commentsDialogVisible" title="评论列表" width="60%">
    <div v-for="comment in comments" :key="comment.id" class="comment-item">
      <div class="comment-info">
        <span class="comment-id">{{ comment.userId }}说:</span>
        <div class="comment-text">{{ comment.text }}</div>
      </div>
      <span class="comment-time">{{ comment.time }}</span>
    </div>
    <el-form :model="commentForm" ref="commentFormRef" @submit.prevent="submitComment">
      <el-form-item label="发表评论" prop="content" label-width="100px">
        <el-input type="textarea" v-model="commentForm.content" autosize placeholder="请输入评论内容"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitComment">提交</el-button>
      </el-form-item>
    </el-form>
    <template #footer>
      <el-button @click="commentsDialogVisible = false">关闭</el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref } from 'vue';
import axios from "../axios";
import { ElMessage } from "element-plus";

// 初始数据
const newsList = ref([]);
const newsDetail = ref('');
const dialogVisible = ref(false);
const commentsDialogVisible = ref(false);
const currentRow = ref({});
const typeOptions = ref([]);
const form = ref({
  typeId: null
});
const comments = ref([]);
const commentForm = ref({ content: '' });

// 请求分类数据
axios.get("/getalltype")
  .then((response) => {
    typeOptions.value = response.data.data;
  })
  .catch((error) => {
    ElMessage.error("分类获取失败");
  });

axios
  .get("/getalllikenews")
  .then((response) => {
    newsList.value = response.data.data;
  })
  .catch((error) => {
    ElMessage.error("数据加载失败: " + error);
  });

const looktype = () => {
  if (!form.value.typeId) {
    ElMessage.error("请选择分类");
    return;
  }
  axios.put('/looktype?typeId=' + encodeURIComponent(form.value.typeId))
    .then(response => {
      newsList.value = response.data.data;
      ElMessage.success("查询成功");
    })
    .catch(error => {
      ElMessage.error("查询失败: " + error.message);
    });
};

const preview = (row) => {
  const id = row.id;
  axios
    .get(`/getnewsdata?id=${encodeURIComponent(id)}`)
    .then((response) => {
      const newsContent = response.data.data;
      const imgRegex = /https?:\/\/[^\s"]+/g;
      const imgUrls = newsContent.match(imgRegex);
      let safeContent = newsContent;
      if (imgUrls) {
        imgUrls.forEach(imgUrl => {
          safeContent = safeContent.replace(imgUrl, `<img src="${imgUrl}" style="max-width:100%; height:auto;" />`);
        });
      }
      newsDetail.value = safeContent;
      dialogVisible.value = true;
    })
    .catch((error) => {
      ElMessage.error("数据加载失败: " + error.message);
    });
};

const toggleLike = (row) => {
  row.liked = !row.liked;
  axios.put('/uplistlike', { id: row.id, liked: row.liked })
    .then(() => {
      ElMessage.success("更新点赞状态成功");
    })
    .catch(error => {
      ElMessage.error("更新点赞状态失败: " + error.message);
    });
};
const showComments = (row) => {
  currentRow.value = row;
  axios.get(`/getcomments?id=${encodeURIComponent(row.id)}`)
    .then(response => {
      comments.value = response.data.data;
      commentsDialogVisible.value = true;
    })
    .catch(error => {
      ElMessage.error("评论加载失败: " + error.message);
    });
};

const submitComment = () => {
  if (!commentForm.value.content) {
    ElMessage.error("评论内容不能为空");
    return;
  }
  axios.post('/addcomment', { newsId: currentRow.value.id, text: commentForm.value.content })
    .then(() => {
      ElMessage.success("评论成功");
      commentForm.value.content = '';
      axios.get(`/getcomments?id=${encodeURIComponent(currentRow.value.id)}`)
        .then(response => {
          comments.value = response.data.data;
          commentsDialogVisible.value = true;
        })
        .catch(error => {
          ElMessage.error("评论加载失败: " + error.message);
        });
    })
    .catch(error => {
      ElMessage.error("评论失败: " + error.message);
      commentForm.value.content = '';
    });
};
</script>

<style>
/* 评论列表样式 */
.comment-list {
  margin: 0;
  padding: 0;
  list-style: none;
}

.comment-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  border-bottom: 1px solid #ebeef5;
}

.comment-item:last-child {
  border-bottom: none;
}

.comment-info {
  display: flex;
  align-items: center;
}

.comment-id {
  font-weight: bold;
  color: #333;
}

.comment-text {
  margin-left: 10px;
  font-size: 14px;
  color: #666;
}

.comment-time {
  font-size: 12px;
  color: #999;
}

.like-button {
  cursor: pointer;
  color: red; /* 点赞后的颜色 */
  transition: color 0.3s;
}

.liked {
  color: #ccc; /* 默认颜色 */
}

/* 基本对话框样式 */
.el-dialog {
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* 标题样式 */
.el-dialog__title {
  font-size: 18px;
  font-weight: bold;
  color: #333;
}

/* 评论列表样式 */
.comment-list {
  margin: 0;
  padding: 0;
  list-style: none;
}

.comment-item {
  padding: 10px;
  border-bottom: 1px solid #ebeef5;
}

.comment-item:last-child {
  border-bottom: none;
}

.comment-item p {
  margin: 0;
  font-size: 14px;
  color: #666;
}

.comment-item p span {
  display: block;
  color: #999;
}

/* 表单样式 */
.el-form {
  margin-top: 20px;
}

.el-form-item__label {
  font-size: 14px;
  color: #333;
}

.el-input__inner {
  border-radius: 4px;
  border-color: #dcdfe6;
}

.el-button {
  border-radius: 20px;
  font-size: 14px;
  padding: 8px 20px;
}

.el-button--primary {
  background-color: #409eff;
  border-color: #409eff;
}

/* 底部按钮样式 */
.dialog-footer {
display: flex;
justify-content: flex-end;
padding: 10px;
}

.dialog-footer .el-button {
margin-left: 10px;
}
</style>