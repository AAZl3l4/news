<script>
import {RouterView,RouterLink} from 'vue-router'
// export default {
//   components: {
//     RouterView
//   }
// };
</script>

<template>
<RouterView/>
</template>

<style>
*{
    margin:0;
    padding:0;
}
</style>
