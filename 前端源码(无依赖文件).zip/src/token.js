import { defineStore } from 'pinia';
import { ref } from 'vue';
export const useTokenStore = defineStore('token',()=>{
	//定义state中的token初始值为空字符串
	const token = ref('')
	//定义修改token的方法
	const setToken = (newToken)=>{
		token.value = newToken
	}
	//定义移除token的方法
	const removeToken = ()=> {
		token.value = ' '
	}
	return {token,setToken,removeToken}
},
{persist:true} //开启persist插件的持久化
)