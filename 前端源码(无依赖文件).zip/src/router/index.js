import {createRouter,createWebHistory} from 'vue-router'

import reg from '../components/reg.vue'
import login from '../components/login.vue'
import home from '../components/home.vue'
import list from '../components/list.vue'
import news from '../components/news.vue'
import PP from '../components/PP.vue'
import homehome from '../components/homehome.vue'
import addnews from '../components/addnews.vue'
import like from '../components/like.vue'
import addnewstype from '../components/addnewstype.vue'
import NotFound from '../components/NotFound.vue'

//创建路由器
const router = createRouter({
	history:createWebHistory(), //指定路由器的工作模式
	routes:[ //一个一个的路由规则
	{
		path: '/',
		component:home, // 根路径 '/' 使用的组件
		children: [
		  {
			path: '',
			component: homehome,
		  },
		  {
			path: 'addnews',
			component: addnews,
		  },
		  {
			path: 'news',
			component: news,
		  },
		  {
			path: 'newss',
			component: addnewstype,
		  },
		  {
			path: 'PP',
			component: PP, // 'PP' 子路由使用的组件
		  },
		  {
			path: 'like',
			component: like, // 'PP' 子路由使用的组件
		  },
		],
	  },
		{
			path:'/reg',
			component:reg,
		},
		{
			path:'/list',
			component:list,
		},
        {
			path:'/login',
			component:login,
		},
		{
			path: '/:catchAll(.*)', // 捕获所有未定义的路径
			component: NotFound // 显示 NotFound 组件
		}
	]
})
//把路由器保留出去
export default router